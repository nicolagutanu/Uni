﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using prep3.Data;
using prep3.Models;

namespace prep3.Controllers
{
    public class MainController : Controller
    {
        private readonly DbWPContext context;
        public MainController(DbWPContext context)
        {
            this.context = context;
        }

        public IActionResult Index()
        {
            return View("Menu");
        }

        public string GetAllPH()
        {
            List<Book> books = context.Book.ToList();
            List<PublishingHouse> publishingHouses = context.PublishingHouse.ToList();
            string result = "<br/><table><thead><th>Id</th><th>Name</th><th>Url</th><th></th></thead>";
            int i = 1;
            foreach (PublishingHouse ph in publishingHouses)
            {
                int idPH = ph.id;
                if (context.Book.Where(b => b.idPublishingHouse == idPH).ToList().Count() == 0)
                {
                    result += "<tr><td><input type='text' id ='id" + i.ToString() + "' value='" + ph.id + "'>" +
                    "</td><td><input type='text' id='name" + i.ToString() + "' value='" + ph.name + "'>" +
                    "</td><td><input type='text' id='url" + i.ToString() + "' value='" + ph.url + "'>" +
                    "</td><td><button onclick='deletePH(" + i.ToString() + ")'>Delete</button>" +
                    "</td></tr>";
                    i += 1;
                }
            }
            result += "</table>";
            return result;
        }

        public string DeletePH(int id, string name, string url)
        {
            PublishingHouse ph = new PublishingHouse(id, name, url);
            context.PublishingHouse.Remove(ph);
            context.SaveChanges();
            return "Publishing house deleted";
        }

        public string GetAll()
        {
            List<PublishingHouse> ph = context.PublishingHouse.ToList();
            string result = "<br/><table><thead><th>Id</th><th>Name</th><th>Url</th><th>Nr of books</th></thead>";
            foreach (PublishingHouse p in ph)
            {
                int count = 0;
                count = context.Book.Where(b => b.idPublishingHouse == p.id).ToList().Count();
                result += "<tr><td>" + p.id +
                    "</td><td>" + p.name +
                    "</td><td>" + p.url +
                    "</td><td>" + count +
                    "</td></tr>";
            }

            result += "</table>";
            return result;
        }

        public string GetBookByTopics(string topics)
        {
            List<Book> books = context.Book.ToList();
            string[] givenTopics = topics.Split(" ");
            string result = "<br/><table><thead><th>Name</th></thead>";
            foreach (Book b in books)
            {
                int count = 0;
                foreach(string top in givenTopics)
                {
                    bool found = false;
                    if (b.topic1 == top)
                        found = true;
                    if (b.topic2 == top)
                        found = true;
                    if (b.topic3 == top)
                        found = true;
                    if (b.topic4 == top)
                        found = true;
                    if (b.topic5 == top)
                        found = true;
                    if (found == true)
                        count += 1;
                }
                if (count == 3)
                {
                    result += "<tr><td>" + b.name +
                    "</td></tr>";
                }
            }

            result += "</table>";
            return result;
        }
    }
}
