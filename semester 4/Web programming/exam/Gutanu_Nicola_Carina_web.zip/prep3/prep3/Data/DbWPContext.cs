﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MySQL.Data.EntityFrameworkCore;
using prep3.Models;

namespace prep3.Data
{
    public class DbWPContext : DbContext
    {
        public DbWPContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Book> Book { get; set; }
        public DbSet<PublishingHouse> PublishingHouse { get; set; }
    }
}
