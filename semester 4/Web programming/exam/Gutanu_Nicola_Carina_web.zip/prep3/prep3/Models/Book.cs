﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace prep3.Models
{
    public class Book
    {
        public int id { get; set; }
        public int idPublishingHouse { get; set; }
        public string name { get; set; }
        public string topic1 { get; set; }
        public string topic2 { get; set; }
        public string topic3 { get; set; }
        public string topic4 { get; set; }
        public string topic5 { get; set; }
    }
}
