﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;
using MySQL.Data.EntityFrameworkCore;
using lab9.Models;

namespace lab9.Data
{
	public class DBWpContext : DbContext
	{
		public DBWpContext(DbContextOptions options) : base(options)
		{
		}

		public DbSet<Recipe> Recipe { get; set; }
		public DbSet<User> User { get; set; }

	}
}
