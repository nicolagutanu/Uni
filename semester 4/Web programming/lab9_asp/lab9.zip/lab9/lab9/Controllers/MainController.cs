﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using lab9.Data;
using lab9.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;

namespace lab9.Controllers
{
    public class MainController : Controller
    {
        private readonly DBWpContext _context;

        public MainController(DBWpContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View("MainPage");
        }

        [HttpGet]
        public IActionResult FilterRecipes()
        {
            
            return View("FilterRecipes");
        }

        public string getRecipesByType(string type)
        {
            List<Recipe> recipes = _context.Recipe.Where(rec => rec.Type == type).ToList();

            string result = "<table><thead><th>Id</th><th>Author</th><th>Name</th><th>Type</th><th>Description</th></thead>";

            foreach (Recipe rec in recipes)
            {
                result += "<tr><td>" + rec.id + "</td><td>" + rec.Author + "</td><td>" + rec.Name + "</td><td>" + rec.Type + "</td><td>" + rec.Description + "</td><td></tr>";
            }

            result += "</table>";
            return result;
        }

        public IActionResult AddRecipe()
        {
            return View("AddRecipe");
        }

        public IActionResult SaveRecipe(string author, string name, string type, string desc)
        {
            List<Recipe> recipes = _context.Recipe.ToList();
            int maxId = recipes.Max(r => r.id);
            Recipe rec = new Recipe();
            rec.id = maxId + 1;
            rec.Author = author;
            rec.Name = name;
            rec.Type = type;
            rec.Description = desc;

            _context.Add(rec);
            _context.SaveChanges();
            return RedirectToAction("GetRecipes");
        }

        public IActionResult GetRecipes()
        {
            List<Recipe> recipes = _context.Recipe.ToList();
            ViewData["recipesList"] = recipes;
            return View("GetRecipes");
        }

        public IActionResult DeleteRecipe()
        {
            List<Recipe> recipes = _context.Recipe.ToList();
            ViewData["recipesList"] = recipes;
            return View("DeleteRecipe");
        }

        public string DeleteRec(int id)
        {
            Recipe rec = new Recipe();
            rec.id = id;

            _context.Remove(rec);
            _context.SaveChanges();
            return "alright";
        }

        public IActionResult UpdateRecipe()
        {
            List<Recipe> recipes = _context.Recipe.ToList();
            ViewData["recipesList"] = recipes;
            return View("UpdateRecipe");
        }

        public string UpdateRec(int id, string author, string name, string type, string desc)
        {
            Recipe rec = new Recipe();
            rec.id = id;
            if (author == null)
                return "no";
            rec.Author = author;
            if (name == null)
                return "no";
            rec.Name = name;
            if (type == null)
                return "no";
            rec.Type = type;
            if (desc == null)
                return "no";
            rec.Description = desc;

            _context.Update(rec);
            _context.SaveChanges();
            return "alright";
        }
    }
}
