﻿using lab9.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using lab9.Data;
using System.Web;
using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Http;

namespace lab9.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly DBWpContext _context;

        public HomeController(ILogger<HomeController> logger, DBWpContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public string Login(string username, string password)
        {
            if (_context.User.Where(user => user.username == username && user.password == password).ToList().Count == 0)
            {
                return "Error";
            }
            return "Success";
        }
    }
}
