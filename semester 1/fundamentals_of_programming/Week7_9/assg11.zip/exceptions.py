class RepoError(Exception):
    pass


class ValidError(Exception):
    pass


class UndoStackError(Exception):
    pass