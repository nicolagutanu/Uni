#pragma once

#include "SortedMultiMap.h"
#include <stack>

using namespace std;


class SMMIterator{
	friend class SortedMultiMap;
private:
	//DO NOT CHANGE THIS PART
	const SortedMultiMap& map;
	SMMIterator(const SortedMultiMap& map);

	//TODO - Representation
	std::stack<int> traversal;
	int currentNode;

public:
	void first();
	void next();
	bool valid() const;
   	TElem getCurrent() const;
};

