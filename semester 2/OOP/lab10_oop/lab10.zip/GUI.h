#pragma once
#include <qwidget.h>
#include "service.h"
#include "qlistwidget.h"
#include "qlineedit.h"
#include "qpushbutton.h"

class GUI :
	public QWidget
{
private:
	Service& service;
	QListWidget* plantsListWidget;
	QLineEdit* codedNameLine, * speciesLine, * ageInMonthsLine, * digitizedScanLine;
	QPushButton* addButton;

public:
	GUI(Service& service);

private:
	void initGUI();
	void populateList();
};

