#include "lab10_oop.h"
#include <QtWidgets/QApplication>
#include "validator.h"
#include "repository.h"
#include "fileRepository.h"
#include "service.h"
#include "csvRepository.h"
#include <memory>
#include "GUI.h"

using namespace std;

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	unique_ptr<Repository> mylist = make_unique<CsvRepository>();
	FileRepository repository{ "E:\\School\\sem2\\OOP\\lab8_oop\\plants.txt.txt" };
	Service service{ &repository, mylist.get() };

	GUI gui{service};
	gui.show();

	return a.exec();
}
