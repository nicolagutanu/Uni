#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_lab10_oop.h"

class lab10_oop : public QMainWindow
{
	Q_OBJECT

public:
	lab10_oop(QWidget *parent = Q_NULLPTR);

private:
	Ui::lab10_oopClass ui;
};
