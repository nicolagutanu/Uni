#include "lab10_oop.h"

lab10_oop::lab10_oop(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
