#include "GUI.h"
#include "qlayout.h"
#include "qformlayout.h"
#include "qgridlayout.h"
#include "service.h"
#include <string>

using namespace std;

GUI::GUI(Service& service) : service{service}
{
	this->initGUI();
	this->populateList();
}

void GUI::initGUI()
{
	this->plantsListWidget = new QListWidget{};
	this->codedNameLine = new QLineEdit{};
	this->speciesLine = new QLineEdit{};
	this->ageInMonthsLine = new QLineEdit{};
	this->digitizedScanLine = new QLineEdit{};
	this->addButton = new QPushButton{ "Add" };

	QVBoxLayout* mainLayout = new QVBoxLayout{ this };
	mainLayout->addWidget(this->plantsListWidget);

	QFormLayout* plantDetailsLayout = new QFormLayout{};
	plantDetailsLayout->addRow("Coded Name", this->codedNameLine);
	plantDetailsLayout->addRow("Species", this->speciesLine);
	plantDetailsLayout->addRow("Age In Months", this->ageInMonthsLine);
	plantDetailsLayout->addRow("Digitized Scan", this->digitizedScanLine);
	mainLayout->addLayout(plantDetailsLayout);

	QGridLayout* buttonsLayout = new QGridLayout{};
	buttonsLayout->addWidget(this->addButton, 0, 0);
	mainLayout->addLayout(buttonsLayout);
}

void GUI::populateList()
{
	this->plantsListWidget->clear();
	vector<Plant> allPlants = this->service.getPlantsService();
	for (Plant& plant : allPlants)
		this->plantsListWidget->addItem(QString::fromStdString(plant.get_codedName() + " - " + plant.get_species() + " " + to_string(plant.get_ageInMonths()) + " " + plant.get_digitizedScan()));
	
}
