#include "lab10_oop.h"
#include <QtWidgets/QApplication>
#include "validator.h"
#include "repository.h"
#include "fileRepository.h"
#include "service.h"
#include "csvRepository.h"
#include <memory>
#include "lab10_oop.h"

using namespace std;

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	unique_ptr<Repository> mylist = make_unique<CsvRepository>("E:\\School\\sem2\\OOP\\lab10_oop\\mylist.txt");
	FileRepository repository{ "E:\\School\\sem2\\OOP\\lab10_oop\\plants.txt.txt" };
	Service service{ &repository, mylist.get() };

	lab10_oop gui{service};
	gui.show();
	
	return a.exec();
}
