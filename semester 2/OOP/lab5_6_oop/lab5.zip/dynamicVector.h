#pragma once
#include "domain.h"
#include <iostream>

class DynamicVector
{
private:

	Plant* elements;
	int capacity; 
	int length;

	void resize(int factor = 2);

public: 
	/* Default constructor */
	DynamicVector(int capacity = 10);

	/* Copy constructor */
	DynamicVector(const DynamicVector& vector_to_copy);

	/* Destructor*/
	~DynamicVector();

	void addPlantToDatabase(const Plant& plantToAdd);
	void deletePlantFromDatabase(const int& position_of_plantToDelete);
	void updatePlantInDatabase(const Plant& newPlant, const int& position_of_plantToUpdate);
	int getLength();
	Plant getElement(const int& position_of_plantToFind);
	Plant* getElements();
};