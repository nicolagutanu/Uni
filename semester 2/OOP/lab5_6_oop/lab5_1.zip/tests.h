#pragma once

void run_tests();