#pragma once

void addStar_validStar_willBeAdded();
void addStar_invalidName_notAdded();
void addStar_invalidDimeter_notAdded();
void addStar_alreadyExists_notAdded();
 
void testAll();

