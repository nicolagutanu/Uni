#include "console.h"
#include "stdio.h"
#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include "repository.h"

int main()
{
	Repository* repo = createRepository();
	OperationStack* undo = createOperationStack();
	OperationStack* redo = createOperationStack();
	Service* serv = createService(repo, undo, redo);
	Console* cons = createConsole(serv);
	run(cons);
	destroyConsole(cons);
	_CrtDumpMemoryLeaks();
	return 0;
}