﻿using System;
using System.Collections.Generic;
using System.Text;

namespace lab4
{
    class Parser
    {
        public static string GetRequestString(string hostname, string endpoint)
        {
            return "GET" + endpoint + "HTTP/1.1\n" +
                "Host: " + hostname + "\n" +
                "Content-Length: 0\n";
        }

        public static int GetContentLength(string response_content)
        {
            int content_length = 0;
            var response_lines = response_content.Split("\n");
            foreach (string rs in response_lines)
            {
                //<header name>:<header value>
                var headline_details = rs.Split(":");
                if (String.Compare(headline_details[0], "Content-Length", StringComparison.Ordinal) == 0)
                {
                    content_length = int.Parse(headline_details[1]);
                }
            }
            return content_length;
        }

        public static bool ResponseHeaderObtained(string response_content)
        {
            return response_content.Contains("\n");
        }
    }
}
