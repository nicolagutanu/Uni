﻿using System.Linq;

namespace lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            var hosts = new string[] { "sarahjmaas.com/", "www.bookdepository.com/", "www.youtube.com/watch?v=QXPUm0iwuOc" }.ToList();
            var task = new EventDriven();
            var task2 = new TaskCallback();
            var task3 = new AsyncAwait();
            //task.start(hosts, 80);
            //task2.start(hosts, 80);
            //task3.start(hosts, 80);
        }
    }
}
