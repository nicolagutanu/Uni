﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace lab4
{
    class MySocket
    {
        public Socket my_socket = null;
        public const int buffer_size = 1024;
        public byte[] buffer = new byte[buffer_size];

        public StringBuilder response_content = new StringBuilder();
        
        public string hostname;
        public string endpoint;
        public IPEndPoint remote_end_point;

        public ManualResetEvent connect_flag = new ManualResetEvent(false);
        public ManualResetEvent send_flag = new ManualResetEvent(false);
        public ManualResetEvent receive_flag = new ManualResetEvent(false);
    }
}
