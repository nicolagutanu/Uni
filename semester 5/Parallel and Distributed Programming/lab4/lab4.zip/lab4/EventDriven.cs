﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace lab4
{
    class EventDriven
    {
        public void start(List<String> hostnames, int port)
        {
            foreach (string host in hostnames)
            {
                ConnectSocket(host, port);
                Thread.Sleep(1000);
            }
        }

        //Connect to server
        private static void ConnectSocket(String host, int port)
        {
            //remote endpoint of server
            var ip_host_info = Dns.GetHostEntry(host.Split("/")[0]);
            var ip_address = ip_host_info.AddressList[0];
            var remote_endpoint = new IPEndPoint(ip_address, port);
            
            //tcp/ip socket
            var client = new Socket(ip_address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //wrapper for connection info
            var request_socket = new MySocket
            {
                my_socket = client,
                hostname = host.Split("/")[0],
                endpoint = host.Contains("/") ? host.Substring(host.IndexOf("/")) : "/",
                remote_end_point = remote_endpoint,
            };

            //actual connecting to remote endpoint of server
            request_socket.my_socket.BeginConnect(request_socket.remote_end_point, Connecting, request_socket);
        }

        private static void Connecting(IAsyncResult ar)
        {
            //information from wrapper for connection information
            var result_socket = (MySocket)ar.AsyncState;
            var client_socket = result_socket.my_socket;
            var hostname = result_socket.hostname;

            //complete connection after getting information
            client_socket.EndConnect(ar);
            Console.WriteLine("Connection: Socket connect to {0} ({1})", hostname, client_socket.RemoteEndPoint);

            //convert string to byte
            var byte_data = Encoding.ASCII.GetBytes(Parser.GetRequestString(result_socket.hostname, result_socket.endpoint));

            //send data to server
            result_socket.my_socket.BeginSend(byte_data, 0, byte_data.Length, 0, Sending, result_socket);
        }

        private static void Sending(IAsyncResult ar)
        {
            //information from wrapper for connection information
            var result_socket = (MySocket)ar.AsyncState;
            var client_socket = result_socket.my_socket;

            //end send data to server
            var bytes_sent = client_socket.EndSend(ar);
            Console.WriteLine("Connection: Sent {0} bytes to server", bytes_sent);

            //receive response from server
            result_socket.my_socket.BeginReceive(result_socket.buffer, 0, MySocket.buffer_size, 0, Receiving, result_socket);
        }

        private static void Receiving(IAsyncResult ar)
        {
            //information from wrapper for connection information
            var result_socket = (MySocket)ar.AsyncState;
            var client_socket = result_socket.my_socket;

            try
            {
                //end receive response from server
                var bytes_read = client_socket.EndReceive(ar);

                //get the content from the buffer
                result_socket.response_content.Append(Encoding.ASCII.GetString(result_socket.buffer, 0, bytes_read));
                if (!Parser.ResponseHeaderObtained(result_socket.response_content.ToString()))
                {
                    //if header not fully obtained, we continue to receive from server
                    client_socket.BeginReceive(result_socket.buffer, 0, MySocket.buffer_size, 0, Receiving, result_socket);
                } 
                else
                {
                    //all data received, write to console length
                    Console.WriteLine("Content length: {0}", Parser.GetContentLength(result_socket.response_content.ToString()));

                    //release socket
                    client_socket.Shutdown(SocketShutdown.Both);
                    client_socket.Close();
                } 
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
