﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace lab4
{
    class TaskCallback
    {
        private static int PORT;
        public void start(List<String> hostnames, int port)
        {
            PORT = port;
            var tasks = new List<Task>();

            foreach (string host in hostnames)
            {
                tasks.Add(Task.Factory.StartNew(DoStart, host));
            }

            Task.WaitAll(tasks.ToArray());
        }

        private static void DoStart(object host_obj)
        {
            var host = (string)host_obj;
            ConnectSocket(host, PORT);
        }

        //Connect to server
        private static void ConnectSocket(String host, int port)
        {
            //remote endpoint of server
            var ip_host_info = Dns.GetHostEntry(host.Split("/")[0]);
            var ip_address = ip_host_info.AddressList[0];
            var remote_endpoint = new IPEndPoint(ip_address, port);

            //tcp/ip socket
            var client = new Socket(ip_address.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

            //wrapper for connection info
            var request_socket = new MySocket
            {
                my_socket = client,
                hostname = host.Split("/")[0],
                endpoint = host.Contains("/") ? host.Substring(host.IndexOf("/")) : "/",
                remote_end_point = remote_endpoint,
            };

            //connect to remote endpoint
            ConnectingWrapper(request_socket).Wait();

            //request data from server
            SendingWrapper(request_socket, Parser.GetRequestString(request_socket.hostname, request_socket.endpoint)).Wait();

            //receive data from server
            ReceivingWrapper(request_socket).Wait();

            //all data received, write to console length
            Console.WriteLine("Content length: {0}", Parser.GetContentLength(request_socket.response_content.ToString()));

            //release socket
            client.Shutdown(SocketShutdown.Both);
            client.Close();
        }

        private static Task ConnectingWrapper(MySocket request_socket)
        {
            // actual connecting to remote endpoint of server
            request_socket.my_socket.BeginConnect(request_socket.remote_end_point, Connecting, request_socket);

            return Task.FromResult(request_socket.connect_flag.WaitOne());
        }

        private static void Connecting(IAsyncResult ar)
        {
            //information from wrapper for connection information
            var result_socket = (MySocket)ar.AsyncState;
            var client_socket = result_socket.my_socket;
            var hostname = result_socket.hostname;

            //complete connection after getting information
            client_socket.EndConnect(ar);
            Console.WriteLine("Connection: Socket connect to {0} ({1})", hostname, client_socket.RemoteEndPoint);

            //flag connection = done
            result_socket.connect_flag.Set();
        }

        private static Task SendingWrapper(MySocket request_socket, string data)
        {
            //convert string to byte
            var byte_data = Encoding.ASCII.GetBytes(data);

            //send data to server
            request_socket.my_socket.BeginSend(byte_data, 0, byte_data.Length, 0, Sending, request_socket);

            return Task.FromResult(request_socket.send_flag.WaitOne());
        }

        private static void Sending(IAsyncResult ar)
        {
            //information from wrapper for connection information
            var result_socket = (MySocket)ar.AsyncState;
            var client_socket = result_socket.my_socket;

            //end send data to server
            var bytes_sent = client_socket.EndSend(ar);
            Console.WriteLine("Connection: Sent {0} bytes to server", bytes_sent);

            //flag sending = done
            result_socket.send_flag.Set();
        }

        private static Task ReceivingWrapper(MySocket request_socket)
        {
            //receive data from server
            request_socket.my_socket.BeginReceive(request_socket.buffer, 0, MySocket.buffer_size, 0, Receiving, request_socket);

            return Task.FromResult(request_socket.receive_flag.WaitOne());
        }

        private static void Receiving(IAsyncResult ar)
        {
            //information from wrapper for connection information
            var result_socket = (MySocket)ar.AsyncState;
            var client_socket = result_socket.my_socket;

            try
            {
                //end receive response from server
                var bytes_read = client_socket.EndReceive(ar);

                //get the content from the buffer
                result_socket.response_content.Append(Encoding.ASCII.GetString(result_socket.buffer, 0, bytes_read));
                if (!Parser.ResponseHeaderObtained(result_socket.response_content.ToString()))
                {
                    //if header not fully obtained, we continue to receive from server
                    client_socket.BeginReceive(result_socket.buffer, 0, MySocket.buffer_size, 0, Receiving, result_socket);
                }
                else
                {
                    //all data received
                    //flag receiving = done
                    result_socket.receive_flag.Set();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
