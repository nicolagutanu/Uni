﻿using System;

namespace rt
{
    public class Sphere : Geometry
    {
        private Vector Center { get; set; }
        private double Radius { get; set; }

        public Sphere(Vector center, double radius, Material material, Color color) : base(material, color)
        {
            Center = center;
            Radius = radius;
        }

        public override Intersection GetIntersection(Line line, double minDist, double maxDist)
        {
            //min/max dist so you're not too close or too far from the camera
            // ADD CODE HERE: Calculate the intersection between the given line and this sphere
            //when we get 2 ts, we take the smallest positive on the line
            double a = line.Dx * line.Dx;
            double b = 2 * line.Dx.X * (line.X0.X - Center.X) + 2 * line.Dx.Y * (line.X0.Y - Center.Y) + 2 * line.Dx.Z * (line.X0.Z - Center.Z);
            double c = (line.X0.X - Center.X) * (line.X0.X - Center.X) + (line.X0.Y - Center.Y) * (line.X0.Y - Center.Y) + (line.X0.Z - Center.Z) * (line.X0.Z - Center.Z) - (Radius * Radius);
            double discriminant = b * b - 4 * a * c;
            if (discriminant < 0)
            {
                return new Intersection(false, false, this, line, 0);
            }
            double t1 = (-b + Math.Sqrt(discriminant)) / (2 * a);
            double t2 = (-b - Math.Sqrt(discriminant)) / (2 * a);
            bool valid_t1 = t1 >= minDist && t1 <= maxDist;
            bool valid_t2 = t2 >= minDist && t2 <= maxDist;
            if (!valid_t1 && !valid_t2)
            {
                return new Intersection(false, false, this, line, 0);
            }
            else if (valid_t1 && !valid_t2)
            {
                return new Intersection(true, true, this, line, t1);
            }
            else if (!valid_t1 && valid_t2)
            {
                return new Intersection(true, true, this, line, t2);
            }
            else if (t1<t2)
            {
                return new Intersection(true, true, this, line, t1);
            }
            else
            {
                return new Intersection(true, true, this, line, t2);
            }
        }

        public override Vector Normal(Vector v)
        {
            var n = v - Center;
            n.Normalize();
            return n;
        }
    }
}