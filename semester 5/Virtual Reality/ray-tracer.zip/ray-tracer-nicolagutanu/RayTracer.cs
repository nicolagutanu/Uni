﻿using System;
using System.Runtime.InteropServices;

namespace rt
{
    class RayTracer
    {
        private Geometry[] geometries;
        private Light[] lights;

        public RayTracer(Geometry[] geometries, Light[] lights)
        {
            this.geometries = geometries;
            this.lights = lights;
        }

        private double ImageToViewPlane(int n, int imgSize, double viewPlaneSize)
        {
            var u = n * viewPlaneSize / imgSize;
            u -= viewPlaneSize / 2;
            return u;
        }

        private Intersection FindFirstIntersection(Line ray, double minDist, double maxDist)
        {
            var intersection = new Intersection();

            foreach (var geometry in geometries)
            {
                var intr = geometry.GetIntersection(ray, minDist, maxDist);

                if (!intr.Valid || !intr.Visible) continue;

                if (!intersection.Valid || !intersection.Visible)
                {
                    intersection = intr;
                }
                else if (intr.T < intersection.T)
                {
                    intersection = intr;
                }
            }

            return intersection;
        }

        private bool IsLit(Vector point, Light light)
        {
            // ADD CODE HERE: Detect whether the given point has a clear line of sight to the given light
            //so if anything is in the line's way to the light, it's in shadow
            //this for later for shadows
            Line line = new Line(point, light.Position);
            Intersection intersection = FindFirstIntersection(line, 0.1, (light.Position - point).Length() - 0.1);
            if (intersection.Valid && intersection.Visible)
                return false;
            return true;
        }

        public void Render(Camera camera, int width, int height, string filename)
        {
            var background = new Color();
            var image = new Image(width, height);
           
            for (var i = 0; i < width; i++)
            {
                for (var j = 0; j < height; j++)
                {
                    // ADD CODE HERE: Implement pixel color calculation
                    //we need to first find the point that intersects the front plane from the camera and then we define the line with it
                    //this is where i define the line
                    //with this line we call FindFirstIntersection: line, front plane and back plane limits, defined as functions in the camera
                    //gives you the first intersection -> that has a geometry -> that has a color
                    //the color goes right bellow this comm in background
                    Vector x0 = camera.Position;
                    Vector x1 = camera.Position + camera.Direction * camera.ViewPlaneDistance + (camera.Direction ^ camera.Up) * ImageToViewPlane(i, width, camera.ViewPlaneWidth) + camera.Up * ImageToViewPlane(j, height, camera.ViewPlaneHeight);
                    Line ray = new Line(x0, x1);
                    Intersection intersection = FindFirstIntersection(ray, camera.FrontPlaneDistance, camera.BackPlaneDistance);
                    Color color = new Color();
                    if (intersection.Valid && intersection.Visible)
                    {
                        color = new Color();
                        foreach (Light light in lights)
                        {
                            color += intersection.Geometry.Material.Ambient * light.Ambient;
                            if (IsLit(intersection.Position, light))
                            {
                                //intersection point
                                var v = intersection.Position;
                                //camera
                                var c = camera.Position;
                                //light
                                var l = light.Position;
                                //intersection point to the light
                                var t = (l - v).Normalize();
                                //line to camera
                                var e = (c - v).Normalize();
                                //normal to the surface
                                var n = ((Sphere)intersection.Geometry).Normal(v);
                                //reflection of the light
                                var r = (n * (n * t) * 2 - t).Normalize();
                                if (n * t > 0)
                                    color += intersection.Geometry.Material.Diffuse * light.Diffuse * (n * t);
                                if (e * r > 0)
                                    color += intersection.Geometry.Material.Specular * light.Specular * Math.Pow(e * r, intersection.Geometry.Material.Shininess);
                                color *= light.Intensity;
                            }
                        }
                    }
                    else
                        color = background;
                    image.SetPixel(i, j, color);
                }
            }

            image.Store(filename);
        }
    }
}