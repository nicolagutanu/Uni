package com.example.myapp.authentication.data

data class User(
    val username: String,
    val password: String
)