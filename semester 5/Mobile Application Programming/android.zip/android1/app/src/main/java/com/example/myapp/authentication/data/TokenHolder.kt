package com.example.myapp.authentication.data

data class TokenHolder(
    val token: String
)