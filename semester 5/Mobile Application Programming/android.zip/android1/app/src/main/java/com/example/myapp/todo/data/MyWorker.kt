package com.example.myapp.todo.data

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.myapp.core.TAG
import com.example.myapp.todo.data.remote.BookApi
import java.lang.Exception

class MyWorker (context: Context, workerParams: WorkerParameters) : CoroutineWorker(context, workerParams) {
    override suspend fun doWork(): Result {
        val operation = inputData.getString("operation")
        val id = inputData.getString("id").orEmpty()
        val title = inputData.getString("title").orEmpty()
        val author = inputData.getString("author").orEmpty()
        val year = inputData.getString("year").orEmpty()
        val published = inputData.getString("published").orEmpty()

        val b = Book(id, title, author, year, published)

        try {
            Log.v(TAG, "work manager - started")
            Log.v(TAG, operation.toString())
            if (operation.equals("save")) {
                val createdBook = BookApi.service.create(b)
            }
            else if (operation.equals("update")) {
                val updatedBook = BookApi.service.update(id, b)
            }

            Log.v(TAG, "work manager = succeeded")
            return Result.success()
        } catch (e: Exception) {
            Log.w(TAG, "work manager - failed", e)
            return Result.failure()
        }
    }

}