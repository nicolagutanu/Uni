package com.example.myapp.todo.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class Book(
    @PrimaryKey @ColumnInfo(name = "_id") val _id: String,
    @ColumnInfo(name = "title") var title: String,
    @ColumnInfo(name = "author") var author: String,
    @ColumnInfo(name = "year") var year: String,
    @ColumnInfo(name = "published") var published: String
) {
    override fun toString(): String {
        return "$title, $author, $year, $published"
    }
}