package com.example.myapp

import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController

class AnimationsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_animation, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        view.findViewById<Button>(R.id.button_move_next).setOnClickListener {
            findNavController().navigate(R.id.action_AnimationsFragment_to_BookListFragment)
        }
        revealAndHideView()
        changeViewPositionByValueAnimator()
        changeViewSizeByValueAnimator()
        letsTryColoring()
    }

    private fun changeViewPositionByValueAnimator() {
        ValueAnimator.ofFloat(0f, 100f).apply {
            duration = 5000
            start()
            addUpdateListener {
                view?.findViewById<TextView>(R.id.text_hello)?.translationX = it.animatedValue as Float
            }
        }
    }

    private fun changeViewSizeByValueAnimator() {
        ValueAnimator.ofFloat(0f, 2f).apply {
            duration = 5000
            start()
            addUpdateListener {
                view?.findViewById<TextView>(R.id.text_hello)?.textScaleX = it.animatedValue as Float
            }
        }
    }

    private fun revealAndHideView() {
        view?.findViewById<Button>(R.id.button_reveal)?.setOnClickListener {
            view?.findViewById<TextView>(R.id.text_hello)?.apply {
                alpha = 0f
                visibility = View.VISIBLE
                animate()
                    .alpha(1f)
                    .setDuration(5000)
                    .setListener(null)
            }
        }

        view?.findViewById<Button>(R.id.button_hide)?.setOnClickListener {
            view?.findViewById<TextView>(R.id.text_hello)?.apply {
                alpha = 1f
                visibility = View.VISIBLE
                animate()
                    .alpha(0f)
                    .setDuration(5000)
                    .setListener(null)
            }
        }
    }

    private fun letsTryColoring() {
        val backgroundColorAnimator = ObjectAnimator.ofObject(
            view,
            "backgroundColor",
            ArgbEvaluator(),
            -0x1,
            -0x873a07
        )
        backgroundColorAnimator.duration = 3000
        backgroundColorAnimator.start()
    }
}