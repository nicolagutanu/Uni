package com.example.myapp.todo.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.work.*
import com.example.myapp.core.Result
import com.example.myapp.core.TAG
import com.example.myapp.todo.data.local.BookDao
import com.example.myapp.todo.data.remote.BookApi
import java.lang.Exception

class BookRepository(private val bookDao: BookDao) {
    val books = bookDao.getAll()

    suspend fun refresh(): Result<Boolean> {
        try {
            val books = BookApi.service.getAll()
            for (book in books) {
                bookDao.insert(book)
            }
            return Result.Success(true)
        } catch (e: Exception) {
            return Result.Error(e)
        }
    }

    fun getById(bookId: String): LiveData<Book> {
        return bookDao.getById(bookId)
    }

    suspend fun save(book: Book): Result<Book> {
        try {
            val createdBook = BookApi.service.create(book)
            bookDao.insert(createdBook)
            return Result.Success(createdBook)
        } catch (e: Exception) {
            bookDao.insert(book)

            Log.v(TAG, "worker started")
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val inputData = Data.Builder()
                .putString("operation", "save")
                .putString("id", book._id)
                .putString("title", book.title)
                .putString("author", book.author)
                .putString("year", book.year)
                .putString("published", book.published)
                .build()

            val myWorker = OneTimeWorkRequest.Builder(MyWorker::class.java)
                .setConstraints(constraints)
                .setInputData(inputData)
                .build()

            WorkManager.getInstance().enqueue(myWorker)

            return Result.Error(e)
        }
    }

    suspend fun update(book: Book): Result<Book> {
        try {
            val updatedBook = BookApi.service.update(book._id, book)
            bookDao.update(updatedBook)
            return Result.Success(updatedBook)
        } catch (e: Exception) {
            bookDao.update(book)

            Log.v(TAG, "worker started")
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build()

            val inputData = Data.Builder()
                .putString("operation", "update")
                .putString("id", book._id)
                .putString("title", book.title)
                .putString("author", book.author)
                .putString("year", book.year)
                .putString("published", book.published)
                .build()

            val myWorker = OneTimeWorkRequest.Builder(MyWorker::class.java)
                .setConstraints(constraints)
                .setInputData(inputData)
                .build()

            WorkManager.getInstance().enqueue(myWorker)

            return Result.Error(e)
        }
    }
}