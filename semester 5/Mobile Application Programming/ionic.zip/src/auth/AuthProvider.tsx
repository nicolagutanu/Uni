import {getLogger} from "../core";
import React, {useCallback, useEffect, useState} from "react";
import PropTypes from "prop-types";
import { login as loginApi } from './authApi';
import {Plugins} from "@capacitor/core";

const log = getLogger('AuthProvider');
const { Storage } = Plugins;

type LoginFn = (username?: string, password?: string) => void;
type LogoutFn = () => void;

export interface AuthState {
    authenticationError: Error | null;
    isAuthenticated: boolean;
    isAuthenticating: boolean;
    login?: LoginFn;
    logout?: LogoutFn;
    pendingAuthentication?: boolean;
    username?: string;
    password?: string;
    token: string;
}

const initialState: AuthState = {
    isAuthenticated: false,
    isAuthenticating: false,
    authenticationError: null,
    pendingAuthentication: false,
    token: '',
}

export const AuthContext = React.createContext<AuthState>(initialState);

interface AuthProviderProps {
    children: PropTypes.ReactNodeLike,
}

export const AuthProvider: React.FC<AuthProviderProps> = ({children}) => {
    const [state, setState] = useState<AuthState>(initialState);
    const { isAuthenticated, isAuthenticating, authenticationError, pendingAuthentication, token } = state;
    const login = useCallback<LoginFn>(loginCallback, []);
    const logout = useCallback<LogoutFn>(logoutCallback, []);
    useEffect(authenticationEffect, [pendingAuthentication]);
    const value = { isAuthenticated, login, logout, isAuthenticating, authenticationError, token };
    log('render');
    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );

    function loginCallback(username?: string, password?: string): void {
        log('login');
        setState({
            ...state,
            pendingAuthentication: true,
            username,
            password
        });
    }

    function logoutCallback() {
        log('logout');
        setState({
            ...state,
            token: '',
            isAuthenticated: false
        });
        (async () => await Storage.clear()) ();
        log(Storage);
    }

    function authenticationEffect() {
        let cancelled = false;
        authenticate();
        return () => {
            cancelled = true;
        }

        async function authenticate() {
            var token = await Storage.get({key : "user"});
            if (token.value !== null) {
                log('User found', token.value);
                setState({...state, token: token.value, pendingAuthentication: false, isAuthenticated: true, isAuthenticating: false});
            } else {
                log('User not found');
            }
            if (!pendingAuthentication) {
                log('authenticating, !pendingAuthentication, return');
                return;
            }
            try {
                log('authenticating...');
                setState({...state, isAuthenticating: true,});
                const { username, password } = state;
                const { token } = await loginApi(username, password);
                if (cancelled) {
                    return;
                }

                log('authentication succeeded');
                setState({...state, token, pendingAuthentication: false, isAuthenticated: true, isAuthenticating: false,});
                await Storage.set({
                    key: "user",
                    value: token
                });
            } catch (error: any) {
                if (cancelled) {
                    return;
                }
                log('authentication failed');
                setState({...state, authenticationError: error, pendingAuthentication: false, isAuthenticating: false,});
            }
        }
    }
};