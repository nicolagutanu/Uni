import React from 'react';
import {getLogger} from "../core";
import {BookProps} from "./BookProps";
import {IonImg, IonItem, IonLabel} from "@ionic/react";

const log = getLogger('Book');

interface BookPropsExt extends BookProps {
    onEdit: (_id?: string) => void;
}

const Book: React.FC<BookPropsExt> = ({ _id, title, author, year, published, latitude, longitude, img_url, onEdit }) => {
    //log(`render ${title}`);
    return (
        <IonItem onClick={() => onEdit(_id)}>
            <IonLabel>{title}</IonLabel>
            <IonLabel>{author}</IonLabel>
            <IonLabel>{year}</IonLabel>
            <IonLabel>{published}</IonLabel>
            <IonLabel>{latitude}</IonLabel>
            <IonLabel>{longitude}</IonLabel>
            <IonImg src={img_url} />
        </IonItem>
    );
};

export default Book;