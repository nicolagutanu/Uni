import React, {useContext, useState} from "react";
import {
    IonContent,
    IonHeader, IonItem,
    IonList,
    IonPage,
    IonSearchbar,
    IonTitle,
    IonToolbar,
    useIonViewWillEnter
} from "@ionic/react";
import {AuthContext} from "../auth";
import {getBooks} from "./bookApi";

const Search: React.FC = () => {
    const { token } = useContext(AuthContext);
    const [books, setBooks] = useState<string[]>([]);
    const [searchBook, setSearchBook] = useState<string>('');

    async function fetchBooks() {
        const booksFound = await getBooks(token);
        setBooks(booksFound.map(b => b.title));
    }

    useIonViewWillEnter(async () => {
        await fetchBooks();
    });

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Search</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen>
                <IonSearchbar
                    value={searchBook}
                    debounce={1000}
                    onIonChange={e => setSearchBook(e.detail.value!)}>
                </IonSearchbar>
                <IonList>
                    {books
                        .filter(book => book.indexOf(searchBook) >= 0)
                        .map(book => <IonItem key={book}>{book}</IonItem>)}
                </IonList>
            </IonContent>
        </IonPage>
    );
};

export default Search;