import {
    createAnimation,
    IonContent,
    IonFab,
    IonFabButton,
    IonHeader,
    IonIcon, IonList,
    IonLoading,
    IonPage,
    IonTitle,
    IonToolbar
} from '@ionic/react';
import React, {useContext} from 'react';
import Book from "./Book";
import {getLogger} from "../core";
import {add} from "ionicons/icons";
import {RouteComponentProps} from "react-router";
import {BookContext} from "./BookProvider";
import {useAppState} from "./useAppState";
import {useNetwork} from "./useNetwork";
import {useBackgroundTask} from "./useBackgroundTask";
import {AuthContext} from "../auth";

const log = getLogger('BookList');

const BookList: React.FC<RouteComponentProps> = ({ history }) => {
    const { books, fetching, fetchingError } = useContext(BookContext);
    const { appState} = useAppState();
    const { networkStatus } = useNetwork();
    const { logout } = useContext(AuthContext);
    useBackgroundTask(() => new Promise(resolve => {
        log('My background task');
        resolve();
    }));

    const animation_add = createAnimation()
        .addElement(document.querySelector(".button_add")!)
        .easing("ease-in-out")
        .duration(1000)
        .direction("alternate")
        .iterations(Infinity)
        .keyframes([
            { offset: 0, transform: "scale(1)", opacity: "1" },
            { offset: 1, transform: "scale(1.5)", opacity: "0.5" }
        ]);
    animation_add.play().then(r => console.log(r));

    const animation_logout = createAnimation()
        .addElement(document.querySelector('.button_logout')!)
        .duration(1500)
        .iterations(Infinity)
        .direction('alternate')
        .fromTo('background', 'red', 'var(--background)');
    animation_logout.play().then(r => console.log(r));

    log('render');
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Library</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonLoading isOpen={fetching} message="Fetching books" />
                {books && (
                    <IonList>
                        {books.map(({_id, title, author, year, published, latitude, longitude, img_url }) =>
                            <Book key={_id} _id={_id} title={title} author={author} year={year} published={published} latitude={latitude} longitude={longitude} img_url={img_url} onEdit={id => history.push(`/book/${id}`)} />)}
                    </IonList>
                )}
                {fetchingError && (
                    <div>{fetchingError.message || 'Failed to fetch books'}</div>
                )}
                <IonFab className="button_add" vertical="bottom" horizontal="end" slot="fixed">
                    <IonFabButton onClick={() => history.push('/book')}>
                        <IonIcon icon={add} />
                    </IonFabButton>
                </IonFab>
                <IonFab className="button_logout" vertical="bottom" horizontal="start" slot="fixed">
                    <IonFabButton color="light" href="/login" onClick={handleLogout}>Log out</IonFabButton>
                </IonFab>
                <br/>
                <div>App state is {JSON.stringify(appState)}</div>
                <div>Network status is {JSON.stringify(networkStatus)}</div>
            </IonContent>
        </IonPage>
    );

    function handleLogout() {
        log("logout");
        logout?.();
    }
};

export default BookList;