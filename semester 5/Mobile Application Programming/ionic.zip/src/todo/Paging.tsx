import React, {useContext, useState} from "react";
import {
    IonCard,
    IonContent,
    IonHeader,
    IonInfiniteScroll, IonInfiniteScrollContent, IonLabel,
    IonPage,
    IonTitle,
    IonToolbar,
    useIonViewWillEnter
} from "@ionic/react";
import {AuthContext} from "../auth";
import {getBooks} from "./bookApi";
import {BookProps} from "./BookProps";

const Paging: React.FC = () => {
    const { token } = useContext(AuthContext);
    const [books, setBooks] = useState<BookProps[]>([]);
    const [disableInfiniteScroll, setDisableInfiniteScroll] = useState<boolean>(false);

    async function fetchData() {
        const booksFound = await getBooks(token);
        if (booksFound && booksFound.length > 0) {
            setBooks([...booksFound]);
            setDisableInfiniteScroll(booksFound.length < 10);
        } else {
            setDisableInfiniteScroll(true);
        }
    }

    useIonViewWillEnter(async () => {
        await fetchData();
    });

    async function searchNext($event: CustomEvent<void>) {
        await fetchData();
        ($event.target as HTMLIonInfiniteScrollElement).complete();
    }

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Future available books</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent fullscreen>
                {books.map(({_id, title, author, year, published }) => {
                    return <IonCard key={_id}>
                        <IonLabel>{title}</IonLabel>
                    </IonCard>
                })}
                <IonInfiniteScroll threshold="100px" disabled={disableInfiniteScroll}
                                   onIonInfinite={(e: CustomEvent<void>) => searchNext(e)}>
                    <IonInfiniteScrollContent
                        loadingText="Loading more books...">
                    </IonInfiniteScrollContent>
                </IonInfiniteScroll>
            </IonContent>
        </IonPage>
    );
};

export default Paging;