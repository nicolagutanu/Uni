import { useEffect } from 'react';
import { Plugins } from '@capacitor/core';
import {getLogger} from "../core";

const { BackgroundTask } = Plugins;

const log = getLogger('useBackgroundTask');

export const useBackgroundTask = (asyncTask: () => Promise<void>) => {
    useEffect(() => {
        let taskId = BackgroundTask.beforeExit(async () => {
            log('executeTask started');
            await asyncTask();
            log('executeTask finished');
            BackgroundTask.finish({ taskId });
        });
    }, [])
    return {};
};
