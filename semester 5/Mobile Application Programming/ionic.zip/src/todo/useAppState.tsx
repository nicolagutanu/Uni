import { useEffect, useState } from 'react';
import {AppState, Plugins} from "@capacitor/core";
import {getLogger} from "../core";

const { App } = Plugins;

const log = getLogger('useAppState');

const initialState = {
    isActive: true,
}

export const useAppState = () => {
    const [appState, setAppState] = useState(initialState);
    useEffect(() => {
        const handler = App.addListener('appStateChange', handleAppStateChange);
        App.getState().then(handleAppStateChange);
        let cancelled = false;
        return () => {
            cancelled = true;
            handler.remove();
        }

        function handleAppStateChange(state: AppState) {
            log('state change', state);
            if (!cancelled) {
                setAppState(state);
            }
        }
    }, [])
    return { appState };
};
