import React, {useContext, useEffect, useState} from "react";
import {
    IonCard,
    IonContent,
    IonHeader, IonInfiniteScroll, IonInfiniteScrollContent, IonItem, IonLabel,
    IonList,
    IonPage,
    IonSearchbar, IonSelect, IonSelectOption,
    IonTitle,
    IonToolbar,
    useIonViewWillEnter
} from "@ionic/react";
import {AuthContext} from "../auth";
import {getBooks} from "./bookApi";
import {map} from "ionicons/icons";

const Filtering: React.FC = () => {
    const { token } = useContext(AuthContext);
    const [years, setYears] = useState<string[]>([]);
    const [books, setBooks] = useState<string[]>([]);
    const [filter, setFilter] = useState<string|undefined>(undefined);
    const [disableInfiniteScroll, setDisableInfiniteScroll] = useState<boolean>(false);

    async function fetchBooks() {
        const yearsFound = await getBooks(token);
        let years: string[] = [];
        for (let y of yearsFound) {
            if (!years.includes(y.year)) {
                years.push(y.year);
            }
        }
        setYears(years);
    }

    async function fetchData(reset?: boolean) {
        const all_books : string[] = reset ? []: books;
        const booksFound = await getBooks(token);
        setBooks([...booksFound.filter(b => b.year === filter).map(filtered_book => filtered_book.title), ...all_books]);
    }

    useEffect(() => {
        fetchData(true);
    }, [filter]);

    async function searchNext($event: CustomEvent<void>) {
        await fetchData();
        ($event.target as HTMLIonInfiniteScrollElement).complete();
    }

    useIonViewWillEnter(async () => {
        await fetchBooks();
    });

    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Search</IonTitle>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonSelect value={filter} placeholder="Select Year" onIonChange={e => setFilter(e.detail.value)}>
                    {years.map(year => <IonSelectOption key={year} value={year}>{year}</IonSelectOption>)}
                </IonSelect>
                {books.map(book => {
                    return <IonCard key={book}>
                        <IonLabel>{book}</IonLabel>
                    </IonCard>
                })}
                <IonInfiniteScroll threshold="100px" disabled={disableInfiniteScroll}
                                   onIonInfinite={(e: CustomEvent<void>) => searchNext(e)}>
                    <IonInfiniteScrollContent
                        loadingText="Loading more good doggos...">
                    </IonInfiniteScrollContent>
                </IonInfiniteScroll>
            </IonContent>
        </IonPage>
    );
};

export default Filtering;