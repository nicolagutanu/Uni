import React, { useContext, useEffect, useState } from 'react';
import {
    IonActionSheet,
    IonButton,
    IonButtons, IonCol,
    IonContent, IonFab, IonFabButton, IonGrid,
    IonHeader, IonIcon, IonImg,
    IonInput,
    IonLoading,
    IonPage, IonRow,
    IonTitle,
    IonToolbar
} from '@ionic/react';
import { getLogger } from '../core';
import { RouteComponentProps } from 'react-router';
import {BookProps} from "./BookProps";
import {BookContext} from "./BookProvider";
import {useMyLocation} from "../location/useMyLocation";
import {MyMap} from "../location/MyMap";
import {Photo, usePhotoGallery} from "../camera/usePhotoGallery";
import {camera, trash, close} from "ionicons/icons";
import {Plugins} from "@capacitor/core";

const log = getLogger('BookEdit');
const { Storage } = Plugins;

interface BookEditProps extends RouteComponentProps<{
    id?: string;
}> {}

const BookEdit: React.FC<BookEditProps> = ({ history, match }) => {
    const { books, saving, savingError, saveBook } = useContext(BookContext);
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');
    const [year, setYear] = useState('');
    const [published, setPublished] = useState('');
    const [latitude, setLatitude] = useState('');
    const [longitude, setLongitude] = useState('');
    const [img_url, setImgUrl] = useState('');
    const [book, setBook] = useState<BookProps>();
    useEffect(() => {
        log('useEffect');
        const routeId = match.params.id || '';
        const book = books?.find(b => b._id === routeId);
        setBook(book);
        if (book) {
            setTitle(book.title);
            setAuthor(book.author);
            setYear(book.year);
            setPublished(book.published);
            setLatitude(book.latitude);
            setLongitude(book.longitude);
            setImgUrl(book.img_url);
        }
    }, [match.params.id, books]);
    const handleSave = () => {
        const editedBook = book ? { ...book, title, author, year, published, latitude, longitude, img_url} : { title, author, year, published, latitude, longitude, img_url };
        console.log(editedBook);
        saveBook && saveBook(editedBook).then(() => history.goBack());
    };

    const myLocation = useMyLocation();
    const { latitude: lat, longitude: lng} = myLocation.position?.coords || {};

    const { photos, takePhoto, deletePhoto } = usePhotoGallery();
    const [photoToDelete, setPhotoToDelete] = useState<Photo>();
    log('render');
    return (
        <IonPage>
            <IonHeader>
                <IonToolbar>
                    <IonTitle>Edit Book</IonTitle>
                    <IonButtons slot="end">
                        <IonButton onClick={handleSave}>
                            Save
                        </IonButton>
                    </IonButtons>
                </IonToolbar>
            </IonHeader>
            <IonContent>
                <IonInput value={title} placeholder="Title" onIonChange={e => setTitle(e.detail.value || '')} />
                <IonInput value={author} placeholder="Author" onIonChange={e => setAuthor(e.detail.value || '')} />
                <IonInput value={year} placeholder="Year" onIonChange={e => setYear(e.detail.value || '')} />
                <IonInput value={published} placeholder="Published" onIonChange={e => setPublished(e.detail.value || '')} />
                <IonLoading isOpen={saving} />
                {savingError && (
                    <div>{savingError.message || 'Failed to save book'}</div>
                )}
                <br/>
                <h4>Please set a location:</h4>
                {lat && lng &&
                <MyMap
                    lat={lat}
                    lng={lng}
                    onMapClick={log('onMap')}
                    onMarkerClick={log('onMarker')}
                />}
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <IonGrid>
                    <IonRow>
                        {photos.map((photo, index) => (
                            <IonCol size="6" key={index}>
                                <IonImg onClick={() => setPhotoToDelete(photo)}
                                        src={photo.webviewPath} />
                            </IonCol>
                        ))}
                    </IonRow>
                </IonGrid>
                <IonFab vertical="bottom" horizontal="center" slot="fixed">
                    <IonFabButton onClick={() => {var t = takePhoto(); t.then(r => setImgUrl(r.replace(/["]+/g, '')))}}>
                        <IonIcon icon={camera}/>
                    </IonFabButton>
                </IonFab>
                <IonActionSheet
                    isOpen={!!photoToDelete}
                    buttons={[{
                        text: 'Delete',
                        role: 'destructive',
                        icon: trash,
                        handler: () => {
                            if (photoToDelete) {
                                deletePhoto(photoToDelete);
                                setPhotoToDelete(undefined);
                            }
                        }
                    }, {
                        text: 'Cancel',
                        icon: close,
                        role: 'cancel'
                    }]}
                    onDidDismiss={() => setPhotoToDelete(undefined)}
                />
            </IonContent>
        </IonPage>
    );

    function log(source: string) {
        return (e: any) => {
            console.log(source, e.latLng.lat(), e.latLng.lng());
            setLatitude(e.latLng.lat());
            setLongitude(e.latLng.lng());
        }
    }
};

export default BookEdit;