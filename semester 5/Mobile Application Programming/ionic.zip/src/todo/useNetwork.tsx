import { useEffect, useState } from 'react';
import {getLogger} from "../core";
import {NetworkStatus, Plugins} from "@capacitor/core";

const { Network } = Plugins;

const log = getLogger('useNetwork');

const initialState = {
    connected: false,
    connectionType: 'unknown',
}

export const useNetwork = () => {
    const [networkStatus, setNetworkStatus] = useState(initialState);
    useEffect(() => {
        const handler = Network.addListener('networkStatusChange', handleNetworkStatusChange);
        Network.getStatus().then(handleNetworkStatusChange);
        let cancelled = false;
        return () => {
            cancelled = true;
            handler.remove();
        }

        function handleNetworkStatusChange(status: NetworkStatus) {
            log('status change', status);
            if (!cancelled) {
                setNetworkStatus(status);
            }
        }
    }, [])
    return { networkStatus };
};