import axios from 'axios';
import {authConfig, config, getLogger, withLogs} from '../core';
import {BookProps} from "./BookProps";

const baseUrl = 'http://localhost:3000';
const bookUrl = `${baseUrl}/api/book`;

export const getBooks: (token: string) => Promise<BookProps[]> = token => {
    return withLogs(axios.get(bookUrl, authConfig(token)), 'getBooks');
}

export const createBook: (token: string, book: BookProps) => Promise<BookProps[]> = (token, book) => {
    console.log(book);
    return withLogs(axios.post(bookUrl, book, authConfig(token)), 'createBook');
}

export const updateBook: (token: string, book: BookProps) => Promise<BookProps[]> = (token, book) => {
    return withLogs(axios.put(`${bookUrl}/${book._id}`, book, authConfig(token)), 'updateBook');
}

interface MessageData {
    type: string;
    payload: BookProps;
}

const log = getLogger('ws');

export const newWebSocket = (token: string, onMessage: (data: MessageData) => void) => {
    const ws = new WebSocket(`ws://localhost:3000`)
    ws.onopen = () => {
        log('web socket open');
        ws.send(JSON.stringify({ type: 'authorization', payload: { token } }));
    };
    ws.onclose = () => {
        log('web socket close');
    };
    ws.onerror = error => {
        log('web socket error', error);
    };
    ws.onmessage = messageEvent => {
        log('web socket message');
        onMessage(JSON.parse(messageEvent.data));
    };
    return () => {
        ws.close();
    }
}