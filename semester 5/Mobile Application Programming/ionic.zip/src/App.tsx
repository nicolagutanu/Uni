import { Redirect, Route } from 'react-router-dom';
import {IonApp, IonIcon, IonLabel, IonRouterOutlet, IonTabBar, IonTabButton, IonTabs} from '@ionic/react';
import { IonReactRouter } from '@ionic/react-router';

/* Core CSS required for Ionic components to work properly */
import '@ionic/react/css/core.css';

/* Basic CSS for apps built with Ionic */
import '@ionic/react/css/normalize.css';
import '@ionic/react/css/structure.css';
import '@ionic/react/css/typography.css';

/* Optional CSS utils that can be commented out */
import '@ionic/react/css/padding.css';
import '@ionic/react/css/float-elements.css';
import '@ionic/react/css/text-alignment.css';
import '@ionic/react/css/text-transformation.css';
import '@ionic/react/css/flex-utils.css';
import '@ionic/react/css/display.css';

/* Theme variables */
import './theme/variables.css';
import {BookEdit, BookList} from "./todo";
import {BookProvider} from "./todo/BookProvider";
import {AuthProvider, Login, PrivateRoute} from "./auth";
import Paging from "./todo/Paging";
import Filtering from "./todo/Filtering";
import Animations from "./animation/Animations";
import {ellipse, square, triangle} from "ionicons/icons";
import Search from "./todo/Search";

const App: React.FC = () => (
    <IonApp>
        <IonReactRouter>
            <IonTabs>
                <IonRouterOutlet>
                    <AuthProvider>
                        <Route path="/login" component={Login} exact={true}/>
                        <BookProvider>
                            <PrivateRoute path="/books" component={BookList} exact={true} />
                            <PrivateRoute path="/book" component={BookEdit} exact={true} />
                            <PrivateRoute path="/book/:id" component={BookEdit} exact={true} />
                            <PrivateRoute component={Paging} path="/paging" exact={true} />
                            <PrivateRoute component={Search} path="/search" exact={true} />
                            <PrivateRoute component={Filtering} path="/filter" exact={true} />
                            <PrivateRoute component={Animations} path="/animation" exact={true} />
                        </BookProvider>
                        <Route exact path="/" render={() => <Redirect to="/books"/>}/>
                    </AuthProvider>
                </IonRouterOutlet>
                <IonTabBar slot="bottom">
                    <IonTabButton tab="My Books" href="/books">
                        <IonLabel>My Books</IonLabel>
                    </IonTabButton>
                    <IonTabButton tab="Paging" href="/paging">
                        <IonLabel>Paging</IonLabel>
                    </IonTabButton>
                    <IonTabButton tab="Search" href="/search">
                        <IonLabel>Search</IonLabel>
                    </IonTabButton>
                    <IonTabButton tab="Filter" href="/filter">
                        <IonLabel>Filter</IonLabel>
                    </IonTabButton>
                    <IonTabButton tab="Animations" href="/animation">
                        <IonLabel>Animation</IonLabel>
                    </IonTabButton>
                </IonTabBar>
            </IonTabs>
        </IonReactRouter>
    </IonApp>
);

export default App;
